<?php
    $conn = mysqli_connect('localhost','root', '', "ecommerceshop");
    mysqli_set_charset($conn,'utf8');
?>