<div class="modal-detail" id="modal-detail">
    <div class="modal-item" id="modal-item">
        <section class="product-details spad">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6 col-md-6">
                        <div class="product__details__pic">
                            <div class="product__details__pic__item">
                                <img class="product__details__pic__item--large" src="img/product/details/pic-1.jpg"
                                    alt="">
                            </div>
                            <div class="product__details__pic__slider owl-carousel">
                                <img data-imgbigurl="img/product/details/pic-1.jpg" src="img/product/details/pic-1.jpg"
                                    alt="">
                                <img data-imgbigurl="img/product/details/pic-2.jpg" src="img/product/details/pic-2.jpg"
                                    alt="">
                                <img data-imgbigurl="img/product/details/pic-3.jpg" src="img/product/details/pic-3.jpg"
                                    alt="">
                                <img data-imgbigurl="img/product/details/pic4.jpg" src="img/product/details/pic-4.jpg"
                                    alt="">
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6">
                        <div class="product__details__text">
                            <h3>Serum</h3>
                            <div class="product__details__rating">
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star"></i>
                                <i class="fa fa-star-half-o"></i>
                                <span>(18 reviews)</span>
                            </div>
                            <div class="product__details__price">500000 VNĐ</div>
                            <p>Mauris blandit aliquet elit, eget tincidunt nibh pulvinar a. Vestibulum ac diam sit amet
                                quam
                                vehicula elementum sed sit amet dui. Sed porttitor lectus nibh. Vestibulum ac diam sit
                                amet
                                quam vehicula elementum sed sit amet dui. Proin eget tortor risus.</p>
                            <div class="product__details__quantity">
                                <div class="quantity">
                                    <div class="pro-qty">
                                        <input type="text" value="1">
                                    </div>
                                </div>
                            </div>
                            <a href="#" class="primary-btn">Thêm vào giỏ hàng</a>
                            <a href="#" class="heart-icon"><span class="icon_heart_alt"></span></a>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <div id="btn-close"><i class="fa-solid fa-xmark"></i></div>
    </div>
</div>